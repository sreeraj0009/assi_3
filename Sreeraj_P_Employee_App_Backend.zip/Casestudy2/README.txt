ASSIGNMENT 3 - EMPLOYEE APP BACKEND INTEGRATION

SETUP
1. Install Node.js (LTS) if it is not already installed.
2. Open the Casestudy2 folder in VS Code.
3. Open a terminal in that folder and run:
      npm install
4. Create a file named .env (copy .env.example) and replace the sample MONGODB_URI
   with your own MongoDB Atlas connection string. Do not share or upload your real .env.
5. In MongoDB Atlas, allow your current IP address in Network Access and create a database user.
6. Run the application:
      npm run dev
7. Open http://localhost:3000

API ROUTES
GET     /api/employeelist       - list all employees
GET     /api/employeelist/:id   - get one employee
POST    /api/employeelist       - add employee
PUT     /api/employeelist       - update employee (send _id or id in JSON body)
DELETE  /api/employeelist/:id   - delete employee

Employee JSON fields: name, location, position, salary

NOTE
The supplied dist/Frontend build files are included unchanged. The .env file is intentionally
not included because it must contain your private MongoDB Atlas credentials.
