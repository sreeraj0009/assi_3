// Assignment 3 - Employee App Backend Integration
// Install dependencies with: npm install
// Add your MongoDB Atlas connection string to .env before running.

const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Read JSON request bodies sent by the frontend.
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve the supplied frontend build from its actual folder name.
const path = require('path');
app.use(express.static(path.join(__dirname, 'dist', 'Frontend')));

// Task2: Connect to MongoDB Atlas.
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('Connected to MongoDB Atlas'))
  .catch((error) => console.error('MongoDB connection error:', error.message));

// Employee database model.
const employeeSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  location: { type: String, required: true, trim: true },
  position: { type: String, required: true, trim: true },
  salary: { type: Number, required: true, min: 0 }
}, { timestamps: true });

const Employee = mongoose.models.Employee || mongoose.model('Employee', employeeSchema);

// API error handling and routes.

// TODO: get data from db using api '/api/employeelist'
app.get('/api/employeelist', async (req, res) => {
  try {
    const employees = await Employee.find().sort({ createdAt: -1 });
    res.status(200).json(employees);
  } catch (error) {
    res.status(500).json({ message: 'Failed to retrieve employees', error: error.message });
  }
});

// TODO: get single data from db using api '/api/employeelist/:id'
app.get('/api/employeelist/:id', async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Invalid employee ID' });
    }
    const employee = await Employee.findById(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });
    res.status(200).json(employee);
  } catch (error) {
    res.status(500).json({ message: 'Failed to retrieve employee', error: error.message });
  }
});

// TODO: send data to db using api '/api/employeelist'
// Request body format: {name:'', location:'', position:'', salary:''}
app.post('/api/employeelist', async (req, res) => {
  try {
    const { name, location, position, salary } = req.body;
    if (!name || !location || !position || salary === undefined || salary === '') {
      return res.status(400).json({ message: 'Please provide name, location, position and salary' });
    }
    const employee = await Employee.create({ name, location, position, salary: Number(salary) });
    res.status(201).json(employee);
  } catch (error) {
    res.status(400).json({ message: 'Failed to add employee', error: error.message });
  }
});

// TODO: delete employee data using api '/api/employeelist/:id'
app.delete('/api/employeelist/:id', async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Invalid employee ID' });
    }
    const employee = await Employee.findByIdAndDelete(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });
    res.status(200).json({ message: 'Employee deleted successfully', employee });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete employee', error: error.message });
  }
});

// TODO: update employee data using api '/api/employeelist'
// Request body format: {name:'', location:'', position:'', salary:''}
// The supplied frontend sends the employee ID in the request body.
app.put('/api/employeelist', async (req, res) => {
  try {
    const { _id, id, name, location, position, salary } = req.body;
    const employeeId = _id || id;
    if (!employeeId || !mongoose.isValidObjectId(employeeId)) {
      return res.status(400).json({ message: 'A valid employee ID is required in _id or id' });
    }
    const updates = {};
    if (name !== undefined) updates.name = name;
    if (location !== undefined) updates.location = location;
    if (position !== undefined) updates.position = position;
    if (salary !== undefined && salary !== '') updates.salary = Number(salary);

    const employee = await Employee.findByIdAndUpdate(employeeId, updates, {
      new: true,
      runValidators: true
    });
    if (!employee) return res.status(404).json({ message: 'Employee not found' });
    res.status(200).json(employee);
  } catch (error) {
    res.status(400).json({ message: 'Failed to update employee', error: error.message });
  }
});

// Keep the supplied frontend route working.
app.get('/*', function (req, res) {
  res.sendFile(path.join(__dirname + '/dist/Frontend/index.html'));
});

app.listen(PORT, () => {
  console.log(`Employee App API running on port ${PORT}`);
});
